package ex10;



import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.sun.management.VMOption.Origin;

public class ProductsHandler {
	private static final String tableName = "products";
	private static final String allQuery = "select * from " + tableName;
	private static final String productAdd = "insert into " + tableName+ " (pName,origin,price,inventory) values(?,?,?,?)";
	private static final String idQueryByName="select id from "+tableName+" where pname = ? ";
	
	private List<Product> products;
	private static final String drivers ="com.mysql.jdbc.Driver";
	private static final String url="jdbc:mysql://localhost/test_db?useUnicode=true&characterEncoding=utf8";
	private static final String username="debian-sys-maint";
	private static final String password="0rtETXXww4B7NhqH";
	
	public ProductsHandler(){
		products=new ArrayList<Product>();
		try {
			loadAllProducts();
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

	public List<Product> getProducts() {
		return products;
	}



	public Product getProduct(String name){
		for(Product p:this.products){
			if(p.getpName().equals(name)){
				return p; 
			}
		}
		return null;
	}

	public boolean addProduct(String name,String origin,float price,int inventory) throws IOException, SQLException {
		boolean flag=false;
		try(Connection conn=getConnection();
			PreparedStatement stat = conn.prepareStatement(productAdd);
				){
			
			stat.setString(1, name);
			stat.setString(2, origin);
			stat.setString(3, String.valueOf(price));
			stat.setString(4,String.valueOf(inventory));
			flag=(stat.executeUpdate()>0)?true:false;
			
		
			
		}
		return flag;
	}

	private void loadAllProducts() throws SQLException, IOException {
		try(Connection conn=getConnection();
			PreparedStatement stat=conn.prepareStatement(allQuery);
			){
				try(ResultSet rs=stat.executeQuery()){
					while(rs.next()){
						int id=rs.getInt("id");
						String pName=rs.getString("pName");
						String origin=rs.getString("origin");
						float price=rs.getInt("price");
						int inventory=rs.getInt("inventory");
						Product product =new Product(id,pName,origin,price,inventory);
						products.add(product);
					}
				}
			}
	}
	

	private static Connection getConnection() throws IOException,SQLException {
//		Properties props=new Properties();
		
//		String path="jdbc.properites";
//		try(FileInputStream in =new FileInputStream(path)){
//			props.load(in);
//		}
//		String drivers=props.getProperty("jdbc.drivers");
		if(drivers!=null) System.setProperty("jdbc.drivers",drivers);
		try {
			Class.forName(drivers);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		String url=props.getProperty("jdbc.url");
//		String username=props.getProperty("jdbc.username");
//		String password = props.getProperty("jdbc.password");
		return DriverManager.getConnection(url, username, password);

	}
	
	// private static String resultToString(ResultSet rs) throws SQLException {
	// 	StringBuffer sb = new StringBuffer();
	// 	ResultSetMetaData metaData = rs.getMetaData();
	// 	int columnCount = metaData.getColumnCount();
	// 	for(int i=1;i<=columnCount;i++){
	// 		sb.append(metaData.getColumnLabel(i)+" ");
	// 	}
	// 	sb.append('\n');
	// 	while(rs.next()){
	// 		for(int i=1;i<=columnCount;i++){
	// 			sb.append(rs.getString(i)+" ");
	// 		}
	// 	}
	// 	return sb.toString();
	// }
	

}
