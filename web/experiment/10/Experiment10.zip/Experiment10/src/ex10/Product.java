package ex10;

public class Product {
	int id;
	String pName;
	String origin;
	float price;
	int inventory;
	
	public Product() {
		this.id=0;
		this.pName="";
		this.origin="";
		this.price=0.0f;
		this.inventory=0;
		
	}

	public Product(int id, String pName, String origin, float price, int inventory) {
		super();
		this.id = id;
		this.pName = pName;
		this.origin = origin;
		this.price = price;
		this.inventory = inventory;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getInventory() {
		return inventory;
	}

	public void setInventory(int inventory) {
		this.inventory = inventory;
	}
	
	
	

}
